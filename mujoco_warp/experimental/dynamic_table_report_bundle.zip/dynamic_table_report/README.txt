DynamicTable report sharing package

Extract this ZIP, then open index.html in a browser.

The report and animated collision demo work offline. Images are in media/.
Recorded GPU frames and results are embedded in the demo and also provided as JSON.
Linked implementation sources are bundled under sources/.
Source snapshots are for inspection; running simulations requires the experimental Warp and mjwarp repositories.

Measurements: 8192 worlds, 384 steps, RTX PRO 6000 Blackwell.
Native storage savings come from contact-capacity tuning. The historical DynamicTable snapshot adds downstream storage. The new NativeContactTable replaces independent model-batch contact allocations with a shared transient arena consumed directly by the native solver.
