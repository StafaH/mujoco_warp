// SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "api.h"

// defines all crt + builtin types
#include "builtin.h"

#include "apic_types.h"

#include <cstdint>

#define WP_CURRENT_STREAM ((void*)0xffffffffffffffff)

// Capture modes accepted by wp_cuda_graph_begin_capture. Values match
// cudaStreamCaptureMode so the int can be passed straight through.
#define WP_CUDA_GRAPH_CAPTURE_MODE_GLOBAL       0
#define WP_CUDA_GRAPH_CAPTURE_MODE_THREAD_LOCAL 1
#define WP_CUDA_GRAPH_CAPTURE_MODE_RELAXED      2

enum wp_memory_kind {
    WP_MEMORY_KIND_UNKNOWN = 0,
    WP_MEMORY_KIND_HOST = 1,
    WP_MEMORY_KIND_PINNED = 2,
    WP_MEMORY_KIND_CUDA_DEVICE = 3,
    WP_MEMORY_KIND_CUDA_MEMPOOL = 4,
    WP_MEMORY_KIND_CUDA_MANAGED = 5,
};

enum wp_volume_validation_result {
    WP_VOLUME_VALIDATION_INVALID = 0,
    WP_VOLUME_VALIDATION_SUCCESS = 1,
    WP_VOLUME_VALIDATION_UNSUPPORTED_LAYOUT = 2,
};

struct timing_result_t;

// this is the core runtime API exposed on the DLL level
extern "C" {
WP_API int wp_init(const char* expected_version);
// WP_API void wp_shutdown();

// get error message from C++
WP_API const char* wp_get_error_string();

// allow disabling error output, which is handy during tests that expect failure
WP_API void wp_set_error_output_enabled(int enable);
WP_API int wp_is_error_output_enabled();

// whether Warp was compiled with CUDA support
WP_API int wp_is_cuda_enabled();
// whether Warp was compiled with enhanced CUDA compatibility
WP_API int wp_is_cuda_compatibility_enabled();
// whether Warp was compiled with MathDx support
WP_API int wp_is_mathdx_enabled();
// whether Warp was compiled with cuBQL support
WP_API int wp_is_cubql_enabled();
// whether Warp was compiled with debug support
WP_API int wp_is_debug_enabled();

WP_API uint16_t wp_float_to_half_bits(float x);
WP_API float wp_half_bits_to_float(uint16_t u);

WP_API uint16_t wp_float_to_bfloat16_bits(float x);
WP_API float wp_bfloat16_bits_to_float(uint16_t u);

WP_API void* wp_alloc_host(size_t s, const char* tag = nullptr);
WP_API void* wp_alloc_pinned(size_t s, const char* tag = nullptr);
WP_API void* wp_alloc_device(void* context, size_t s, const char* tag = nullptr);
WP_API void* wp_alloc_device_default(void* context, size_t s, const char* tag = nullptr);
WP_API void*
wp_alloc_device_async(void* context, size_t s, void* stream = WP_CURRENT_STREAM, const char* tag = nullptr);
WP_API void* wp_alloc_device_managed(void* context, size_t s, const char* tag = nullptr);
WP_API void* wp_virtual_memory_create(void* context, size_t size, void** ptr, size_t* reserved, size_t* granularity);
WP_API bool wp_virtual_memory_commit(void* allocation, size_t size);
WP_API bool wp_virtual_memory_destroy(void* allocation, bool defer = false);

WP_API void* wp_capture_scratch_create(void* context, void* ptr, size_t capacity);
WP_API bool wp_capture_scratch_destroy(void* arena);
WP_API bool wp_capture_scratch_begin(void* arena);
WP_API bool wp_capture_scratch_end(void* arena);
WP_API void* wp_capture_scratch_alloc(void* arena, size_t size);
WP_API size_t wp_capture_scratch_used(void* arena);
WP_API bool wp_capture_scratch_exhausted(void* arena);
WP_API bool wp_capture_scratch_rewind(void* arena);

WP_API void wp_free_host(void* ptr);
WP_API void wp_free_pinned(void* ptr);
WP_API void wp_free_device(void* context, void* ptr);  // uses cudaFreeAsync() if supported, cudaFree() otherwise
WP_API void wp_free_device_default(void* context, void* ptr);  // uses cudaFree()
WP_API void wp_free_device_async(void* context, void* ptr, void** dbg_node_ret = nullptr);  // uses cudaFreeAsync()

WP_API bool wp_memcpy_h2h(void* dest, void* src, size_t n);
WP_API bool wp_memcpy_h2d(void* context, void* dest, void* src, size_t n, void* stream = WP_CURRENT_STREAM);
WP_API bool wp_memcpy_d2h(void* context, void* dest, void* src, size_t n, void* stream = WP_CURRENT_STREAM);
WP_API bool wp_memcpy_d2d(void* context, void* dest, void* src, size_t n, void* stream = WP_CURRENT_STREAM);
WP_API bool
wp_memcpy_p2p(void* dst_context, void* dst, void* src_context, void* src, size_t n, void* stream = WP_CURRENT_STREAM);

WP_API bool
wp_memcpy_batch(void* context, void** dsts, void** srcs, size_t* sizes, size_t count, void* stream = WP_CURRENT_STREAM);

WP_API bool wp_memset_host(void* dest, int value, size_t n);
WP_API bool wp_memset_device(void* context, void* dest, int value, size_t n, void* stream = WP_CURRENT_STREAM);

// takes srcsize bytes starting at src and repeats them n times at dst (writes srcsize * n bytes in total):
WP_API void wp_memtile_host(void* dest, const void* src, size_t srcsize, size_t n);
WP_API void wp_memtile_device(void* context, void* dest, const void* src, size_t srcsize, size_t n);

WP_API uint64_t
wp_bvh_create_host(wp::vec3* lowers, wp::vec3* uppers, int num_items, int constructor_type, int* groups, int leaf_size);
WP_API void wp_bvh_destroy_host(uint64_t id);
WP_API void wp_bvh_refit_host(uint64_t id);
WP_API void wp_bvh_rebuild_host(uint64_t id, int constructor_type);

WP_API uint64_t wp_bvh_create_device(
    void* context, wp::vec3* lowers, wp::vec3* uppers, int num_items, int constructor_type, int* groups, int leaf_size
);
WP_API void wp_bvh_destroy_device(uint64_t id);
WP_API void wp_bvh_refit_device(uint64_t id);
WP_API void wp_bvh_rebuild_device(uint64_t id);

// create a user-accessible copy of the mesh, it is the
// users responsibility to keep-alive the points/tris data for the duration of the mesh lifetime
WP_API uint64_t wp_mesh_create_host(
    wp::array_t<wp::vec3> points,
    wp::array_t<wp::vec3> velocities,
    wp::array_t<int> tris,
    int num_points,
    int num_tris,
    int support_winding_number,
    int constructor_type,
    int* groups,
    int bvh_leaf_size
);
WP_API void wp_mesh_destroy_host(uint64_t id);
WP_API void wp_mesh_refit_host(uint64_t id);

WP_API uint64_t wp_mesh_create_device(
    void* context,
    wp::array_t<wp::vec3> points,
    wp::array_t<wp::vec3> velocities,
    wp::array_t<int> tris,
    int num_points,
    int num_tris,
    int support_winding_number,
    int constructor_type,
    int* groups,
    int bvh_leaf_size
);
WP_API void wp_mesh_destroy_device(uint64_t id);
WP_API int wp_mesh_refit_device(uint64_t id);

WP_API void wp_mesh_set_points_host(uint64_t id, wp::array_t<wp::vec3> points);
WP_API int wp_mesh_set_points_device(uint64_t id, wp::array_t<wp::vec3> points);

WP_API void wp_mesh_set_velocities_host(uint64_t id, wp::array_t<wp::vec3> velocities);
WP_API void wp_mesh_set_velocities_device(uint64_t id, wp::array_t<wp::vec3> velocities);

// Hash grid (type: 0=float16, 1=float32, 2=float64)
WP_API uint64_t wp_hash_grid_create_host(int type, int dim_x, int dim_y, int dim_z);
WP_API void wp_hash_grid_destroy_host(uint64_t id, int type);
WP_API void wp_hash_grid_update_host(uint64_t id, int type, double cell_width, const void* points, const void* groups);
WP_API void wp_hash_grid_reserve_host(uint64_t id, int type, int num_points, bool with_groups);

WP_API uint64_t wp_hash_grid_create_device(void* context, int type, int dim_x, int dim_y, int dim_z);
WP_API void wp_hash_grid_destroy_device(uint64_t id, int type);
WP_API void
wp_hash_grid_update_device(uint64_t id, int type, double cell_width, const void* points, const void* groups);
WP_API void wp_hash_grid_reserve_device(uint64_t id, int type, int num_points, bool with_groups);

WP_API int wp_volume_validate_host(const void* buf, uint64_t size);
WP_API uint64_t wp_volume_create_host(void* buf, uint64_t size, bool copy, bool owner);
WP_API void wp_volume_get_tiles_host(uint64_t id, void* buf);
WP_API void wp_volume_get_voxels_host(uint64_t id, void* buf);
WP_API void wp_volume_destroy_host(uint64_t id);

WP_API uint64_t wp_volume_from_tiles_host(
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    const void* bg_value,
    uint32_t bg_value_size,
    const char* bg_value_type,
    bool rebuildable,
    uint32_t max_tiles,
    uint32_t max_lower_nodes,
    uint32_t max_upper_nodes,
    uint32_t* status
);
WP_API uint64_t wp_volume_index_from_tiles_host(
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    bool rebuildable,
    uint32_t max_tiles,
    uint32_t max_lower_nodes,
    uint32_t max_upper_nodes,
    uint32_t* status
);
WP_API uint64_t wp_volume_from_active_voxels_host(
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    bool rebuildable,
    uint32_t max_active_voxels,
    uint32_t max_leaf_nodes,
    uint32_t max_lower_nodes,
    uint32_t max_upper_nodes,
    uint32_t* status
);
WP_API void wp_volume_rebuild_from_tiles_host(
    uint64_t id,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    const void* bg_value,
    uint32_t bg_value_size,
    const char* bg_value_type,
    uint32_t* status
);
WP_API void wp_volume_index_rebuild_from_tiles_host(
    uint64_t id,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    uint32_t* status
);
WP_API void wp_volume_rebuild_from_active_voxels_host(
    uint64_t id,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    uint32_t* status
);

WP_API uint64_t wp_volume_create_device(void* context, void* buf, uint64_t size, bool copy, bool owner);
WP_API void wp_volume_get_tiles_device(uint64_t id, void* buf);
WP_API void wp_volume_get_voxels_device(uint64_t id, void* buf);
WP_API void wp_volume_destroy_device(uint64_t id);

WP_API uint64_t wp_volume_from_tiles_device(
    void* context,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    const void* bg_value,
    uint32_t bg_value_size,
    const char* bg_value_type,
    bool rebuildable,
    uint32_t max_tiles,
    uint32_t max_lower_nodes,
    uint32_t max_upper_nodes,
    uint32_t* status
);
WP_API uint64_t wp_volume_index_from_tiles_device(
    void* context,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    bool rebuildable,
    uint32_t max_tiles,
    uint32_t max_lower_nodes,
    uint32_t max_upper_nodes,
    uint32_t* status
);
WP_API uint64_t wp_volume_from_active_voxels_device(
    void* context,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    bool rebuildable,
    uint32_t max_active_voxels,
    uint32_t max_leaf_nodes,
    uint32_t max_lower_nodes,
    uint32_t max_upper_nodes,
    uint32_t* status
);
WP_API void wp_volume_rebuild_from_tiles_device(
    uint64_t id,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    const void* bg_value,
    uint32_t bg_value_size,
    const char* bg_value_type,
    uint32_t* status
);
WP_API void wp_volume_index_rebuild_from_tiles_device(
    uint64_t id,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    uint32_t* status
);
WP_API void wp_volume_rebuild_from_active_voxels_device(
    uint64_t id,
    void* points,
    int num_points,
    const int32_t* point_mask,
    float transform[9],
    float translation[3],
    bool points_in_world_space,
    uint32_t* status
);

WP_API void wp_volume_get_buffer_info(uint64_t id, void** buf, uint64_t* size);
WP_API void wp_volume_get_voxel_size(uint64_t id, float* dx, float* dy, float* dz);
WP_API void wp_volume_get_tile_and_voxel_count(uint64_t id, uint32_t& tile_count, uint64_t& voxel_count);
WP_API void wp_volume_get_active_stats(
    uint64_t id, uint64_t* voxel_count, uint32_t* leaf_count, uint32_t* lower_count, uint32_t* upper_count
);
WP_API const char* wp_volume_get_grid_info(
    uint64_t id,
    uint64_t* grid_size,
    uint32_t* grid_index,
    uint32_t* grid_count,
    float translation[3],
    float transform[9],
    char type_str[16]
);
WP_API uint32_t wp_volume_get_blind_data_count(uint64_t id);
WP_API const char* wp_volume_get_blind_data_info(
    uint64_t id, uint32_t data_index, void** buf, uint64_t* value_count, uint32_t* value_size, char type_str[16]
);

// Textures
WP_API uint64_t wp_texture_create_device(
    void* context, int ndim, int* shape, int num_channels, int dtype, bool surface_access, int num_mip_levels
);
WP_API void wp_texture_destroy_device(void* context, uint64_t array_handle, bool is_mipmapped);
WP_API uint64_t wp_texture_get_mip_level_array_device(void* context, uint64_t mipmap_array_handle, int level);

WP_API uint64_t wp_texture_create_host(
    int ndim,
    int num_mip_levels,
    int* mip_widths,
    int* mip_heights,
    int* mip_depths,
    int num_channels,
    int dtype,
    int filter_mode,
    int mip_filter_mode,
    int* address_modes,
    bool use_normalized_coords,
    void** mip_data_ptrs_out
);
WP_API void wp_texture_destroy_host(uint64_t tex_handle);

WP_API bool
wp_texture_descriptor_from_cuda_array(void* context, uint64_t array_handle, wp::cuda_array_desc_t* desc_out);

WP_API uint64_t wp_texture_object_create_device(
    void* context,
    uint64_t array_handle,
    int ndim,
    int filter_mode,
    int mip_filter_mode,
    int* address_modes,
    bool use_normalized_coords,
    int num_mip_levels
);
WP_API void wp_texture_object_destroy_device(void* context, uint64_t tex_handle);

WP_API uint64_t wp_surface_object_create_device(void* context, uint64_t array_handle);
WP_API void wp_surface_object_destroy_device(void* context, uint64_t surface_handle);

WP_API bool wp_texture_copy_device(
    void* context,
    unsigned width_bytes,
    unsigned height,
    unsigned depth,
    int dst_memory_type,
    uint64_t dst_handle,
    unsigned dst_pitch,
    unsigned dst_height,
    int src_memory_type,
    uint64_t src_handle,
    unsigned src_pitch,
    unsigned src_height,
    void* stream
);

WP_API uint64_t wp_marching_cubes_create_device(void* context);
WP_API void wp_marching_cubes_destroy_device(uint64_t id);
WP_API int wp_marching_cubes_surface_device(
    uint64_t id,
    const float* field,
    int nx,
    int ny,
    int nz,
    float threshold,
    wp::vec3* verts,
    int* triangles,
    int max_verts,
    int max_tris,
    int* out_num_verts,
    int* out_num_tris
);

// generic copy supporting non-contiguous arrays
WP_API bool wp_array_copy_host(void* dst, void* src, int dst_type, int src_type, int elem_size);
WP_API bool wp_array_copy_device(void* context, void* dst, void* src, int dst_type, int src_type, int elem_size);

// generic fill for non-contiguous arrays
WP_API void wp_array_fill_host(void* arr, int arr_type, const void* value, int value_size);
WP_API void wp_array_fill_device(void* context, void* arr, int arr_type, const void* value, int value_size);

WP_API void
wp_array_inner_float_host(uint64_t a, uint64_t b, uint64_t out, int count, int stride_a, int stride_b, int type_len);
WP_API void
wp_array_inner_double_host(uint64_t a, uint64_t b, uint64_t out, int count, int stride_a, int stride_b, int type_len);
WP_API void
wp_array_inner_float_device(uint64_t a, uint64_t b, uint64_t out, int count, int stride_a, int stride_b, int type_len);
WP_API void
wp_array_inner_double_device(uint64_t a, uint64_t b, uint64_t out, int count, int stride_a, int stride_b, int type_len);

WP_API void wp_array_sum_float_device(uint64_t a, uint64_t out, int count, int stride, int type_len);
WP_API void wp_array_sum_float_host(uint64_t a, uint64_t out, int count, int stride, int type_len);
WP_API void wp_array_sum_double_host(uint64_t a, uint64_t out, int count, int stride, int type_len);
WP_API void wp_array_sum_double_device(uint64_t a, uint64_t out, int count, int stride, int type_len);

WP_API void
wp_array_scan_int_host(uint64_t in, uint64_t out, int len, int in_stride, int out_stride, int type_len, bool inclusive);
WP_API void wp_array_scan_int64_host(
    uint64_t in, uint64_t out, int len, int in_stride, int out_stride, int type_len, bool inclusive
);
WP_API void wp_array_scan_float_host(
    uint64_t in, uint64_t out, int len, int in_stride, int out_stride, int type_len, bool inclusive
);
WP_API void wp_array_scan_double_host(
    uint64_t in, uint64_t out, int len, int in_stride, int out_stride, int type_len, bool inclusive
);

WP_API bool wp_array_scan_int_device(
    uint64_t in, uint64_t out, int len, int in_stride, int out_stride, int type_len, bool inclusive
);
WP_API bool wp_array_scan_int64_device(
    uint64_t in, uint64_t out, int len, int in_stride, int out_stride, int type_len, bool inclusive
);
WP_API bool wp_array_scan_float_device(
    uint64_t in, uint64_t out, int len, int in_stride, int out_stride, int type_len, bool inclusive
);
WP_API bool wp_array_scan_double_device(
    uint64_t in, uint64_t out, int len, int in_stride, int out_stride, int type_len, bool inclusive
);

WP_API void
wp_radix_sort_pairs_int_host(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);
WP_API void
wp_radix_sort_pairs_int_device(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);

WP_API void
wp_radix_sort_pairs_uint_host(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);
WP_API void
wp_radix_sort_pairs_uint_device(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);

WP_API void
wp_radix_sort_pairs_float_host(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);
WP_API void
wp_radix_sort_pairs_float_device(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);

WP_API void
wp_radix_sort_pairs_double_host(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);
WP_API void
wp_radix_sort_pairs_double_device(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);

WP_API void
wp_radix_sort_pairs_int64_host(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);
WP_API void
wp_radix_sort_pairs_int64_device(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);

WP_API void
wp_radix_sort_pairs_uint64_host(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);
WP_API void
wp_radix_sort_pairs_uint64_device(uint64_t keys, uint64_t values, int n, int begin_bit, int end_bit, int value_size);

WP_API bool wp_segmented_sort_pairs_float_host(
    uint64_t keys,
    uint64_t values,
    int n,
    uint64_t segment_start_indices,
    uint64_t segment_end_indices,
    int num_segments
);
WP_API void wp_segmented_sort_pairs_float_device(
    uint64_t keys,
    uint64_t values,
    int n,
    uint64_t segment_start_indices,
    uint64_t segment_end_indices,
    int num_segments
);

WP_API bool wp_segmented_sort_pairs_int_host(
    uint64_t keys,
    uint64_t values,
    int n,
    uint64_t segment_start_indices,
    uint64_t segment_end_indices,
    int num_segments
);
WP_API void wp_segmented_sort_pairs_int_device(
    uint64_t keys,
    uint64_t values,
    int n,
    uint64_t segment_start_indices,
    uint64_t segment_end_indices,
    int num_segments
);

WP_API void
wp_runlength_encode_int_host(uint64_t values, uint64_t run_values, uint64_t run_lengths, uint64_t run_count, int n);
WP_API void
wp_runlength_encode_int_device(uint64_t values, uint64_t run_values, uint64_t run_lengths, uint64_t run_count, int n);

// Deterministic mode: sort scatter buffer and apply component-wise segmented reduction.
WP_API size_t
wp_deterministic_sort_reduce_workspace_size(int count, int op, int scalar_type, int components, int determinism_level);
WP_API void wp_deterministic_sort_reduce_device(
    uint64_t keys,
    uint64_t values,
    int count,
    uint64_t dest_array,
    int dest_size,
    int op,
    int scalar_type,
    int components,
    int determinism_level,
    uint64_t workspace,
    size_t workspace_size
);
WP_API size_t wp_deterministic_counter_scan_workspace_size(int count);
WP_API void wp_deterministic_counter_scan_device(
    uint64_t keys,
    uint64_t values,
    int count,
    uint64_t prefixes,
    uint64_t counter_bases,
    uint64_t counter_totals,
    int counter_size,
    uint64_t workspace,
    size_t workspace_size
);
WP_API void wp_deterministic_counter_writeback_device(
    uint64_t keys, int count, uint64_t counter_totals, uint64_t counters, int counter_size
);

WP_API void wp_bsr_matrix_from_triplets_host(
    int block_size,
    int scalar_size_in_bytes,
    int row_count,
    int col_count,
    int tpl_nnz_upper_bound,
    const int* tpl_nnz,
    const int* tpl_rows,
    const int* tpl_columns,
    const void* tpl_values,
    const uint64_t scalar_zero_mask,
    bool masked_topology,
    int* summed_block_offsets,
    int* summed_block_indices,
    int* bsr_offsets,
    const int* bsr_row_counts,
    int* bsr_columns
);
WP_API void wp_bsr_matrix_from_triplets_device(
    int block_size,
    int scalar_size_in_bytes,
    int row_count,
    int col_count,
    int tpl_nnz_upper_bound,
    const int* tpl_nnz,
    const int* tpl_rows,
    const int* tpl_columns,
    const void* tpl_values,
    const uint64_t scalar_zero_mask,
    bool masked_topology,
    int* summed_block_offsets,
    int* summed_block_indices,
    int* bsr_offsets,
    const int* bsr_row_counts,
    int* bsr_columns
);

WP_API void wp_bsr_transpose_host(
    int row_count,
    int col_count,
    int nnz,
    const int* bsr_offsets,
    const int* bsr_row_counts,
    const int* bsr_columns,
    int* transposed_bsr_offsets,
    int* transposed_bsr_row_counts,
    int* transposed_bsr_columns,
    int* src_block_indices,
    int* status
);
WP_API void wp_bsr_transpose_device(
    int row_count,
    int col_count,
    int nnz,
    const int* bsr_offsets,
    const int* bsr_row_counts,
    const int* bsr_columns,
    int* transposed_bsr_offsets,
    int* transposed_bsr_row_counts,
    int* transposed_bsr_columns,
    int* src_block_indices,
    int* status
);

WP_API void wp_bsr_compress_inplace_host(
    int row_count,
    int block_size,
    int scalar_size_in_bytes,
    int scalar_type,
    int nnz_upper_bound,
    bool prune_numerical_zeros,
    uint64_t scalar_zero_mask,
    bool make_compact,
    int* bsr_offsets,
    int* bsr_row_counts,
    int* bsr_columns,
    void* bsr_values,
    bool compress_values
);
WP_API void wp_bsr_compress_inplace_device(
    int row_count,
    int block_size,
    int scalar_size_in_bytes,
    int scalar_type,
    int nnz_upper_bound,
    bool prune_numerical_zeros,
    uint64_t scalar_zero_mask,
    bool make_compact,
    int* bsr_offsets,
    int* bsr_row_counts,
    int* bsr_columns,
    void* bsr_values,
    bool compress_values
);


WP_API int wp_cuda_driver_version();  // CUDA driver version
WP_API int wp_cuda_toolkit_version();  // CUDA Toolkit version used to build Warp
WP_API const char* wp_version();  // Warp native library version string
WP_API bool wp_cuda_driver_is_initialized();

WP_API const char* wp_nanovdb_version();  // NanoVDB version string
WP_API const char* wp_host_compiler_version();  // Host C++ compiler version
WP_API const char* wp_libmathdx_version();  // libmathdx version (empty if not built with MathDx)
WP_API int wp_nvrtc_version();  // NVRTC version (encoded as major*1000 + minor*10)
WP_API int wp_is_verify_fp_enabled();  // Whether native lib was built with WP_VERIFY_FP
WP_API int wp_is_fast_math_enabled();  // Whether native lib was built with fast math

WP_API int wp_nvrtc_supported_arch_count();
WP_API void wp_nvrtc_supported_archs(int* archs);

WP_API int wp_cuda_device_get_count();
WP_API void* wp_cuda_device_get_primary_context(int ordinal);
WP_API const char* wp_cuda_device_get_name(int ordinal);
WP_API int wp_cuda_device_get_arch(int ordinal);
WP_API int wp_cuda_device_get_sm_count(int ordinal);
WP_API int wp_cuda_device_get_max_shared_memory(int ordinal);
WP_API void wp_cuda_device_get_uuid(int ordinal, char uuid[16]);
WP_API int wp_cuda_device_get_pci_domain_id(int ordinal);
WP_API int wp_cuda_device_get_pci_bus_id(int ordinal);
WP_API int wp_cuda_device_get_pci_device_id(int ordinal);
WP_API int wp_cuda_device_is_uva(int ordinal);
WP_API int wp_cuda_device_get_pageable_memory_access(int ordinal);
WP_API int wp_cuda_device_get_direct_managed_mem_access_from_host(int ordinal);
WP_API int wp_cuda_device_get_host_native_atomic_supported(int ordinal);
WP_API int wp_cuda_device_get_managed_memory_supported(int ordinal);
WP_API int wp_cuda_device_get_concurrent_managed_access_supported(int ordinal);
WP_API int wp_cuda_pointer_get_memory_kind(void* context, void* ptr);
WP_API int wp_cuda_device_is_mempool_supported(int ordinal);
WP_API int wp_cuda_device_is_ipc_supported(int ordinal);
WP_API int wp_cuda_device_set_mempool_release_threshold(int ordinal, uint64_t threshold);
WP_API uint64_t wp_cuda_device_get_mempool_release_threshold(int ordinal);
WP_API uint64_t wp_cuda_device_get_mempool_used_mem_current(int ordinal);
WP_API uint64_t wp_cuda_device_get_mempool_used_mem_high(int ordinal);
WP_API uint64_t wp_cuda_device_get_graph_mem_current(int ordinal);
WP_API void wp_cuda_device_graph_mem_trim(int ordinal);
WP_API void wp_cuda_device_get_memory_info(int ordinal, size_t* free_mem, size_t* total_mem);

WP_API void* wp_cuda_context_get_current();
WP_API void wp_cuda_context_set_current(void* context);
WP_API void wp_cuda_context_push_current(void* context);
WP_API void wp_cuda_context_pop_current();
WP_API void* wp_cuda_context_create(int device_ordinal);
WP_API void wp_cuda_context_destroy(void* context);
WP_API int wp_cuda_context_get_device_ordinal(void* context);
WP_API int wp_cuda_context_is_primary(void* context);
WP_API void* wp_cuda_context_get_stream(void* context);
WP_API void wp_cuda_context_set_stream(void* context, void* stream, int sync);

// ensures all device side operations have completed in the current context
WP_API void wp_cuda_context_synchronize(void* context);

// profiler control for the current CUDA context (equivalent to cuProfilerStart/cuProfilerStop)
WP_API bool wp_cuda_profiler_start(void* context);
WP_API bool wp_cuda_profiler_stop(void* context);

// return cudaError_t code
WP_API uint64_t wp_cuda_context_check(void* context);

// peer access
WP_API int wp_cuda_is_peer_access_supported(int target_ordinal, int peer_ordinal);
WP_API int wp_cuda_is_peer_access_enabled(void* target_context, void* peer_context);
WP_API int wp_cuda_set_peer_access_enabled(void* target_context, void* peer_context, int enable);
WP_API int wp_cuda_is_mempool_access_enabled(int target_ordinal, int peer_ordinal);
WP_API int wp_cuda_set_mempool_access_enabled(int target_ordinal, int peer_ordinal, int enable);

// inter-process communication
WP_API void wp_cuda_ipc_get_mem_handle(void* ptr, char* out_buffer);
WP_API void* wp_cuda_ipc_open_mem_handle(void* context, char* handle);
WP_API void wp_cuda_ipc_close_mem_handle(void* ptr);
WP_API void wp_cuda_ipc_get_event_handle(void* context, void* event, char* out_buffer);
WP_API void* wp_cuda_ipc_open_event_handle(void* context, char* handle);

WP_API void* wp_cuda_stream_create(void* context, int priority);
WP_API void wp_cuda_stream_destroy(void* context, void* stream);
WP_API int wp_cuda_stream_query(void* stream);
WP_API void wp_cuda_stream_register(void* context, void* stream);
WP_API void wp_cuda_stream_unregister(void* context, void* stream);
WP_API void* wp_cuda_stream_get_current();
WP_API void wp_cuda_stream_synchronize(void* stream);
WP_API void wp_cuda_stream_wait_event(void* stream, void* event, bool external = false);
WP_API void wp_cuda_stream_wait_stream(void* stream, void* other_stream, void* event, bool external = false);
WP_API int wp_cuda_stream_is_capturing(void* stream);
WP_API int wp_cuda_stream_is_blocking(void* stream);
WP_API int wp_cuda_thread_exchange_capture_mode(int mode);
WP_API uint64_t wp_cuda_stream_get_capture_id(void* stream);
WP_API int wp_cuda_stream_get_priority(void* stream);

WP_API void* wp_cuda_event_create(void* context, unsigned flags);
WP_API void wp_cuda_event_destroy(void* event);
WP_API int wp_cuda_event_query(void* event);
WP_API void wp_cuda_event_record(void* event, void* stream, bool external = false);
WP_API void wp_cuda_event_synchronize(void* event);
WP_API float wp_cuda_event_elapsed_time(void* start_event, void* end_event);

WP_API bool wp_cuda_graph_begin_capture(void* context, void* stream, int external, int mode);
WP_API bool wp_cuda_graph_end_capture(void* context, void* stream, void** graph_ret);
WP_API bool wp_cuda_graph_create_exec(void* context, void* stream, void* graph, void** graph_exec_ret);
WP_API bool wp_cuda_graph_launch(void* graph, void* stream);
WP_API bool wp_cuda_graph_destroy(void* context, void* graph);
WP_API bool wp_cuda_graph_exec_destroy(void* context, void* graph_exec);
WP_API bool wp_capture_debug_dot_print(void* graph, const char* path, uint32_t flags);

WP_API bool wp_cuda_graph_insert_if_else(
    void* context, void* stream, int arch, bool use_ptx, int* condition, void** if_graph_ret, void** else_graph_ret
);
WP_API bool wp_cuda_graph_insert_while(
    void* context, void* stream, int arch, bool use_ptx, int* condition, void** body_graph_ret, uint64_t* handle_ret
);
WP_API bool
wp_cuda_graph_set_condition(void* context, void* stream, int arch, bool use_ptx, int* condition, uint64_t handle);
WP_API bool wp_cuda_graph_pause_capture(void* context, void* stream, void** graph_ret);
WP_API bool wp_cuda_graph_resume_capture(void* context, void* stream, void* graph);
WP_API bool wp_cuda_graph_insert_child_graph(void* context, void* stream, void* child_graph);
WP_API bool wp_cuda_graph_check_conditional_body(void* body_graph);

WP_API void* wp_cuda_graph_insert_memcpy(void* context, void* stream, void* dst, void* src, size_t size, int kind);
WP_API bool wp_cuda_graph_insert_memcpy_batch(
    void* context, void* stream, void** dsts, void** srcs, size_t* sizes, int* kinds, int count, void** nodes_ret
);
WP_API bool wp_cuda_graph_update_memcpy(void* graph_exec, void* node, void* dst, void* src, size_t size, int kind);
WP_API bool wp_cuda_graph_update_memcpy_batch(
    void* graph_exec, void** nodes, void** dsts, void** srcs, size_t* sizes, int* kinds, int count
);

WP_API void* wp_cuda_graph_insert_alloc_node(void* context, size_t size);
WP_API void* wp_cuda_graph_insert_free_node(void* context, void* alloc_node);
WP_API void* wp_cuda_graph_insert_empty_node(void* context);
WP_API int wp_cuda_graph_node_depends_on(void* argument, void* referent);
WP_API int wp_cuda_graph_alloc_query(void* alloc, void* arg);

WP_API size_t wp_cuda_compile_program(
    const char* cuda_src,
    const char* program_name,
    int arch,
    const char* arch_suffix,
    const char* include_dir,
    int num_cuda_include_dirs,
    const char** cuda_include_dirs,
    bool debug,
    int optimization_level,
    bool verbose,
    bool verify_fp,
    bool fast_math,
    bool fuse_fp,
    bool lineinfo,
    bool compile_time_trace,
    bool precompiled_headers,
    const char* output_path,
    const char* pch_dir,
    size_t num_ltoirs,
    char** ltoirs,
    size_t* ltoir_sizes,
    int* ltoir_input_types
);
WP_API bool wp_cuda_compile_fft(
    const char* ltoir_output_path,
    const char* symbol_name,
    int num_include_dirs,
    const char** include_dirs,
    const char* mathdx_include_dir,
    int arch,
    int size,
    int elements_per_thread,
    int direction,
    int precision,
    int* shared_memory_size
);
// alignment_A/B/C: per-operand byte alignment for the cuBLASDx Alignment operator; any value <= 0 leaves
// every operand at its default. enable_static_block_dim: non-zero enables cublasdx::experimental::StaticBlockDim.
// suppress_errors: non-zero suppresses the error print when cuBLASDx rejects the configuration (the caller
// retries without the alignment operator).
WP_API bool wp_cuda_compile_dot(
    const char* ltoir_output_path,
    const char* symbol_name,
    int num_include_dirs,
    const char** include_dirs,
    const char* mathdx_include_dir,
    int arch,
    int M,
    int N,
    int K,
    int precision_A,
    int precision_B,
    int precision_C,
    int type,
    int arrangement_A,
    int arrangement_B,
    int arrangement_C,
    int num_threads,
    int lda,
    int ldb,
    int ldc,
    int alignment_A,
    int alignment_B,
    int alignment_C,
    int enable_static_block_dim,
    int suppress_errors
);
WP_API bool wp_cuda_compile_solver(
    const char* fatbin_output_path,
    const char* ltoir_output_path,
    const char* symbol_name,
    int num_include_dirs,
    const char** include_dirs,
    const char* mathdx_include_dir,
    int arch,
    int M,
    int N,
    int K,
    int function,
    int side,
    int diag,
    int precision,
    int arrangement_A,
    int arrangement_B,
    int fill_mode,
    int num_threads
);

// CPU kernel launch with optional APIC recording
WP_API void wp_cpu_launch_kernel(void* func, void* bounds, void* args, void* adj_args, const APICLaunchInfo* apic_info);

WP_API void* wp_cuda_load_module(void* context, const char* ptx);
WP_API void wp_cuda_unload_module(void* context, void* module);
WP_API void* wp_cuda_get_kernel(void* context, void* module, const char* name);
WP_API size_t wp_cuda_launch_kernel(
    void* context,
    void* kernel,
    size_t dim,
    int max_blocks,
    int block_dim,
    int grid_stride,
    int cluster_dim,
    int shared_memory_bytes,
    void** args,
    void* stream,
    const APICLaunchInfo* apic_info
);
WP_API int wp_cuda_get_max_shared_memory(void* context);
WP_API bool wp_cuda_configure_kernel_shared_memory(void* kernel, int size);
// Static (compile-time) shared memory the loaded kernel reserves per block, in bytes.
// Returns -1 if the kernel handle is null or the driver query fails. The dynamic shared
// memory a kernel can be configured for is wp_cuda_get_max_shared_memory() minus this value.
WP_API int wp_cuda_get_kernel_static_shared_memory(void* context, void* kernel);
// Query all public properties for a loaded CUDA function in one batch.
// Returns false if arguments are invalid or any driver query fails. The properties
// buffer is updated only after every query succeeds.
WP_API bool wp_cuda_get_kernel_properties(void* context, void* kernel, int* properties, int property_count);
// Set CUDA Thread Block Cluster attributes on a loaded kernel function.
// For total cluster size > 8 (non-portable range), enables
// CU_FUNC_NON_PORTABLE_CLUSTER_SIZE_ALLOWED. Sizes <= 8 are no-ops at this
// layer (the cluster dimension itself is set via __cluster_dims__ in codegen).
// Returns true on success or no-op; false on driver error.
WP_API bool wp_cuda_set_kernel_cluster_attrs(void* kernel, int cx, int cy, int cz);
// Query the maximum cluster_dim (CTA count, 1D product) usable for *kernel*
// at the given block_dim and dynamic shared memory configuration. Returns
// 1 if the device does not support clusters or on driver error.
WP_API int wp_cuda_get_max_cluster_dim(void* context, void* kernel, int block_dim, int dynamic_smem_bytes);
WP_API bool wp_cuda_get_suggested_block_size(
    void* context, void* kernel, int shared_memory_bytes, int* block_size_out, int* min_grid_size_out
);

WP_API void wp_cuda_set_context_restore_policy(bool always_restore);
WP_API int wp_cuda_get_context_restore_policy();

WP_API bool wp_cuda_graphics_map(void* context, void* resource);
WP_API void wp_cuda_graphics_unmap(void* context, void* resource);
WP_API void wp_cuda_graphics_device_ptr_and_size(void* context, void* resource, uint64_t* ptr, size_t* size);
WP_API void* wp_cuda_graphics_register_gl_buffer(void* context, uint32_t gl_buffer, unsigned int flags);
WP_API void* wp_cuda_graphics_register_gl_image(void* context, uint32_t image, uint32_t target, unsigned int flags);
WP_API uint64_t wp_cuda_graphics_sub_resource_get_mapped_array(
    void* context, void* resource, unsigned int array_index, unsigned int mip_level
);
WP_API void wp_cuda_graphics_unregister_resource(void* context, void* resource);

// CUDA timing
WP_API void wp_cuda_timing_begin(int flags);
WP_API int wp_cuda_timing_get_result_count();
WP_API void wp_cuda_timing_end(timing_result_t* results, int size);

// graph coloring
WP_API int wp_graph_coloring(int num_nodes, wp::array_t<int> edges, int algorithm, wp::array_t<int> node_colors);
WP_API float wp_balance_coloring(
    int num_nodes,
    wp::array_t<int> edges,
    int num_colors,
    float target_max_min_ratio,
    int max_iterations,
    wp::array_t<int> node_colors,
    int* iteration_limit_reached
);

// allocation tracking
WP_API void wp_alloc_tracker_enable(int enable);
WP_API int wp_alloc_tracker_is_enabled();
WP_API void wp_alloc_tracker_reset();
WP_API void wp_alloc_tracker_set_tag(void* ptr, const char* tag);
WP_API void wp_alloc_tracker_push_scope(const char* name);
WP_API void wp_alloc_tracker_pop_scope();
WP_API size_t wp_alloc_tracker_report(char* buf, size_t cap, int sort_order = 0, int max_items = 10);
WP_API size_t wp_alloc_tracker_get_current_bytes();
WP_API size_t wp_alloc_tracker_get_peak_bytes();
WP_API size_t wp_alloc_tracker_get_total_alloc_count();
WP_API size_t wp_alloc_tracker_get_total_alloc_bytes();
WP_API int wp_alloc_tracker_get_live_count();

}  // extern "C"
